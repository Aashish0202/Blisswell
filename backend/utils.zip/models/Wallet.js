const pool = require('../config/db');

const Wallet = {
  // Create wallet for user
  async create(userId, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'INSERT INTO wallets (user_id) VALUES (?)',
      [userId]
    );
    return result.insertId;
  },

  // Get wallet by user ID
  async getByUserId(userId, connection = pool) {
    const conn = connection;
    const [rows] = await conn.execute(
      'SELECT * FROM wallets WHERE user_id = ?',
      [userId]
    );
    return rows[0];
  },

  // Update balance (for deposits) - supports transactions
  async updateBalance(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET balance = balance + ?, updated_at = NOW() WHERE user_id = ?',
      [amount, userId]
    );
    return result.affectedRows > 0;
  },

  // Deduct balance (for purchases) - supports transactions
  async deductBalance(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET balance = balance - ?, updated_at = NOW() WHERE user_id = ? AND balance >= ?',
      [amount, userId, amount]
    );
    return result.affectedRows > 0;
  },

  // Get balance
  async getBalance(userId, connection = pool) {
    const conn = connection;
    const [rows] = await conn.execute(
      'SELECT balance FROM wallets WHERE user_id = ?',
      [userId]
    );
    return rows[0]?.balance || 0;
  },

  // Check if user has sufficient balance
  async hasBalance(userId, amount, connection = pool) {
    const conn = connection;
    const [rows] = await conn.execute(
      'SELECT balance FROM wallets WHERE user_id = ? AND balance >= ?',
      [userId, amount]
    );
    return rows.length > 0;
  },

  // ---- Earning wallet (separate from spendable balance) ----
  // Daily incentive credits accumulate here. Withdrawals debit it.

  // Add incentive earnings (daily credit)
  async addEarnings(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET earnings_balance = earnings_balance + ?, updated_at = NOW() WHERE user_id = ?',
      [amount, userId]
    );
    return result.affectedRows > 0;
  },

  // Debit earnings (when a withdrawal payout is generated)
  async debitEarnings(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET earnings_balance = earnings_balance - ?, updated_at = NOW() WHERE user_id = ? AND earnings_balance >= ?',
      [amount, userId, amount]
    );
    return result.affectedRows > 0;
  },

  // Get earnings balance
  async getEarnings(userId, connection = pool) {
    const conn = connection;
    const [rows] = await conn.execute(
      'SELECT earnings_balance FROM wallets WHERE user_id = ?',
      [userId]
    );
    return rows[0]?.earnings_balance || 0;
  },

  // ---- Repurchase (upgrade) wallet ----
  // Funded by the 20% share of processed withdrawals. Spent exclusively by
  // the auto-repurchase engine when the user upgrades to the next rank.

  // Credit repurchase wallet (withdrawal processing)
  async addRepurchase(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET repurchase_balance = repurchase_balance + ?, updated_at = NOW() WHERE user_id = ?',
      [amount, userId]
    );
    return result.affectedRows > 0;
  },

  // Debit repurchase wallet (auto repurchase). Guarded so it can't go negative.
  async debitRepurchase(userId, amount, connection = pool) {
    const conn = connection;
    const [result] = await conn.execute(
      'UPDATE wallets SET repurchase_balance = repurchase_balance - ?, updated_at = NOW() WHERE user_id = ? AND repurchase_balance >= ?',
      [amount, userId, amount]
    );
    return result.affectedRows > 0;
  },

  // Get repurchase balance
  async getRepurchase(userId, connection = pool) {
    const conn = connection;
    const [rows] = await conn.execute(
      'SELECT repurchase_balance FROM wallets WHERE user_id = ?',
      [userId]
    );
    return rows[0]?.repurchase_balance || 0;
  }
};

module.exports = Wallet;